agent = '/var/www/html/agent.php'
password = 'testingpassword'
url = 'http://localhost/agent.php'

base_folder = '/var/www/html/'
base_url = 'http://localhost/'

debug = False
test_stress_channels = True

su_user = 'testuser'
su_passwd = 'testuser'

sql_dbms = 'mysql'
sql_db = 'test'
sql_user = 'root'
sql_passwd = 'root'
sql_autologin = False